package com.bpothina.inclass06;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by BhaBhaHP on 10/2/2017.
 */

public class Recipies implements Serializable {




        String title,ingredients,href;

    @Override
    public String toString() {
        return "Recipies{" +
                "title='" + title + '\'' +
                ", ingredients='" + ingredients + '\'' +
                ", href='" + href + '\'' +
                '}';
    }

    public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getIngredients() {
            return ingredients;
        }

        public void setIngredients(String ingredients) {
            this.ingredients = ingredients;
        }

        public String getHref() {
            return href;
        }

        public void setHref(String href) {
            this.href = href;
        }



}

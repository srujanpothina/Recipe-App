package com.bpothina.inclass06;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener  {

    ArrayList<Integer> edit_id=new ArrayList<>();
    ArrayList<Integer> id_value = new ArrayList<>();
    ArrayList<String> ingredients=new ArrayList<String>();
    ArrayList<Integer> image_id_value = new ArrayList<>();
    LinearLayout l1;
    MainActivity mainActivity;
    int main_layout_id;
    LinearLayout linerlayout;
    private int numberofEditText = 0;
    String dish="";
    static ArrayList<Recipies> recipiList=new ArrayList<Recipies>();
    String url="http://www.recipepuppy.com/api/?format=xml&";//?i=onions,garlic&q=omelet";

    public int getNumberofEditText() {
        return numberofEditText;
    }


    public void setNumberofEditText(int numberofEditText) {
        this.numberofEditText = numberofEditText;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.search).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText dishname = (EditText) findViewById(R.id.dish_name);
                if (dishname.getText().toString().trim().isEmpty()){
                    Toast.makeText(MainActivity.this,"Dish name is empty",Toast.LENGTH_LONG).show();
                } else {
                    int size = id_value.size();
                    EditText e1;
                    Boolean error = false;
                    for (int j =0;j<size;j++){
                        e1 = (EditText) findViewById(edit_id.get(j));
                        if(e1.getText().toString().trim().isEmpty()){
                            error = true;
                        }
                        else
                        {
                            ingredients.add(e1.getText().toString().trim());
                        }
                    }
                    if (error){
                        Toast.makeText(MainActivity.this,"Ingrdients name is empty",Toast.LENGTH_LONG).show();
                    } else{
//                        Log.d("demo","calling intent");
//

                        for(int i=0;i<ingredients.size();i++)
                        {
                            if(i==0)
                            {
                                url+="i=";
                            }
                            else {
                                url+=",";
                            }

                            url+=ingredients.get(i);

                        }
                        url+="&q=";
                        url+=dishname.getText().toString();
                        Log.d("demo",url);
                        dish+=dishname.getText().toString();
                    }

                    GetData();

                }


            }
        });
        LinearLayout l2 = (LinearLayout) findViewById(R.id.l2);
        setContentView(l2);
        l1 = (LinearLayout) findViewById(R.id.l1);
        linerlayout = new LinearLayout(this);
        linerlayout.setOrientation(LinearLayout.VERTICAL);
        linerlayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        linerlayout.setId(View.generateViewId());
        main_layout_id = linerlayout.getId();
        l1.addView(linerlayout);
        addValueEntered();


    }

    public void GetData()
    {
        new GetAsyncRecepi(this).execute(url);
    }
    public void setDataValue(ArrayList<Recipies> r)
    {
        recipiList=r;
        search();

    }

    public void search()
    {
        Intent intent = new Intent(MainActivity.this,RecipiesActivity.class);
        intent.putExtra("dish",dish);

        intent.putExtra("recipi",recipiList);
        Log.d("demobefore", String.valueOf(recipiList.size()));
        startActivity(intent);
    }
    public void addValueEntered() {
        LinearLayout linearlayout = new LinearLayout(this);
        linearlayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        linearlayout.setOrientation(LinearLayout.HORIZONTAL);
        linearlayout.setId(View.generateViewId());
        id_value.add(linearlayout.getId());
        linerlayout.addView(linearlayout);
        EditText editText = new EditText(this);
        editText.setLayoutParams(new LinearLayout.LayoutParams(900,180));
        editText.setTextSize(20);
        editText.setId(View.generateViewId());
        edit_id.add(editText.getId());
        linearlayout.addView(editText);
        ImageView imageView = new ImageView(this);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(100,120));
        imageView.setImageResource(R.drawable.add);
        imageView.setId(View.generateViewId());
        image_id_value.add(imageView.getId());
        imageView.setOnClickListener(this);
        linearlayout.addView(imageView);
        setNumberofEditText(linearlayout.getId());
    }


    public void onClick(View view) {
        int i = getNumberofEditText();
        Log.d("demo","i value"+i);
        Log.d("demo","value Imageview:" +view.getId());
        Log.d("demo","value");
        int size = id_value.size();
        for (int j =0; j< size;j++){
            Log.d("demo","value Imageview:" +view.getId());
            if ((view.getId()) == image_id_value.get(j)){
                if(size == 5){
                    View myview = findViewById(id_value.get(j));
                    ViewGroup parent = (ViewGroup) myview.getParent();
                    parent.removeView(myview);
                    id_value.remove(j);
                    image_id_value.remove(j);
                    edit_id.remove(j);
                    size = id_value.size();
                    ImageView i1 = (ImageView) findViewById(image_id_value.get(size - 1));
                    i1.setImageResource(R.drawable.add);
                } else if (j == (size - 1)) {
                    Log.d("demo","size1" +size);
                    linerlayout = (LinearLayout) findViewById(main_layout_id);
                    addValueEntered();
                    int x = id_value.size();
                    Log.d("demo","size2" +x);
                    Log.d("demo","2" +id_value.get(x - 2));
                    ImageView i1 = (ImageView) findViewById(image_id_value.get(x - 2));
                    i1.setImageResource(R.drawable.remove);
                    if (id_value.size() == 5){
                        ImageView i2 = (ImageView) findViewById(image_id_value.get(x - 1));
                        i2.setImageResource(R.drawable.remove);
                    }
                } else {
                    Log.d("demo","inside if");
                    View myview = findViewById(id_value.get(j));
                    ViewGroup parent = (ViewGroup) myview.getParent();
                    parent.removeView(myview);
                    id_value.remove(j);
                    image_id_value.remove(j);
                    edit_id.remove(j);
                    size = id_value.size();
                }
            }
        }
    }
}

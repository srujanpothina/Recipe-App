package com.bpothina.inclass06;

import android.util.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by BhaBhaHP on 10/2/2017.
 */

public class RecipieParser {

    public static ArrayList<Recipies> parseContent(InputStream in) throws XmlPullParserException, IOException {
        ArrayList<Recipies> recipiesList=new ArrayList<Recipies>();
        Recipies recipie = null;
        XmlPullParser pullParser = XmlPullParserFactory.newInstance().newPullParser();
        pullParser.setInput(in, "UTF-8");
        int event = pullParser.getEventType();

        while (event != XmlPullParser.END_DOCUMENT) {
            switch (event) {
                case XmlPullParser.START_TAG:
                    if (pullParser.getName().equals("recipe")) {
                        recipie = new Recipies();
                    } else if (pullParser.getName().equals("title")) {
                        if (recipie != null) {
                            //Log.d("demo", String.valueOf(recipie));
                            recipie.setTitle(pullParser.nextText().trim());
                        }
                    } else if (pullParser.getName().equals("href")) {
                        if (recipie != null) {
                            recipie.setHref(pullParser.nextText().trim());
                        }
                    } else if (pullParser.getName().equals("ingredients")) {
                        if (recipie != null) {
                            recipie.setIngredients(pullParser.nextText().trim());
                        }
                    }

                    break;
                case XmlPullParser.END_TAG:
                    if (pullParser.getName().equals("recipe")) {
                        Log.d("demo",recipie.toString());
                        recipiesList.add(recipie);
                    }
                    break;
                default:
                    break;
            }
            event = pullParser.next();
        }
        //for(int i=0;i<recipiesList.size();i++)
            //Log.d("demo", String.valueOf(recipiesList.size()));

        return recipiesList;
    }
}

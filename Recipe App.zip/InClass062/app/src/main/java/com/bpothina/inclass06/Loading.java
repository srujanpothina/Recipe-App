package com.bpothina.inclass06;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

public class Loading extends AppCompatActivity {

    int flag=0;
    String dishname="";
    int currentPosition;

    Bitmap setImageBitmap;
    ArrayList<Recipies> rList=new ArrayList<Recipies>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading);

        if(getIntent().getExtras()!=null)
        {
            dishname=getIntent().getExtras().get("dish").toString();

            //(ArrayList<Questions>) getIntent().getSerializableExtra("questions");
            rList= (ArrayList<Recipies>) getIntent().getSerializableExtra("recipi");

            Log.d("demofinal", String.valueOf(rList.size()));

        }



        if(flag==1) {
            Intent intent = new Intent(Loading.this, RecipiesActivity.class);
            intent.putExtra("dish", dishname);

            intent.putExtra("recipi", rList);
            Log.d("demobefore", String.valueOf(rList.size()));
            finish();
            startActivity(intent);
        }

    }
}

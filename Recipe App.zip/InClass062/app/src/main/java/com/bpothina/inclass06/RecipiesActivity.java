package com.bpothina.inclass06;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class RecipiesActivity extends AppCompatActivity {

    private ProgressBar firstBar = null;
    Button search;
    ArrayList<String> imageURLs;
    String dishname="";
    int currentPosition;

    Bitmap setImageBitmap;
    ArrayList<Recipies> rList=new ArrayList<Recipies>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipies);

        if(getIntent().getExtras()!=null)
        {
            dishname=getIntent().getExtras().get("dish").toString();

            //(ArrayList<Questions>) getIntent().getSerializableExtra("questions");
            rList= (ArrayList<Recipies>) getIntent().getSerializableExtra("recipi");

            Log.d("demofinal", String.valueOf(rList.size()));

        }

        display(rList);
    }

        public void URL(View view)
        {
            TextView tv=(TextView)findViewById(view.getId());
            Intent intent = new Intent(Intent.ACTION_VIEW,Uri.parse(tv.getText().toString()));
            startActivity(intent);


        }
    public  void setData(ArrayList<Recipies> recipes)
    {
        TextView dish=(TextView)findViewById(R.id.dish_name);
        TextView ingredients=(TextView)findViewById(R.id.ingredients);
        TextView url=(TextView)findViewById(R.id.url);
        Log.d("currposi",String.valueOf(currentPosition));

        dish.setText(recipes.get(currentPosition).title);
        ingredients.setText(recipes.get(currentPosition).ingredients);
        url.setText(recipes.get(currentPosition).getHref());

        new GetImage().execute("https://c1.staticflickr.com/5/4286/35513985750_2690303c8b_z.jpg");


    }

    public class GetImage extends AsyncTask<String,Void,Bitmap>

    {

        @Override
        protected Bitmap doInBackground(String... strings) {
            URL url1 = null;
            try
            {
                url1 = new URL(strings[0]);

                //Log.d("demo","value:"+finalRecipe.get(currentPosition).getThumbnail().toString());
                HttpURLConnection con = (HttpURLConnection) url1.openConnection();
                con.setRequestMethod("GET");
                Bitmap image = BitmapFactory.decodeStream(con.getInputStream());
            return image;            }

            catch (Exception ex)
            {
                Log.d("exception",ex.toString());
            }

            return null;
        }

        @Override
        protected void onPostExecute(Bitmap image) {

            setImageBitmap=image;
            ImageView img=(ImageView)findViewById(R.id.dish_image);
            img.setImageBitmap(image);

        }
    }
    public void position(ArrayList<Recipies> recipes)
    {
        final ImageView fastfor=(ImageView)findViewById(R.id.fast_forward);
        final ImageView fastback=(ImageView)findViewById(R.id.fast_backward);
        final ImageView forward=(ImageView)findViewById(R.id.forward);
        final ImageView backward=(ImageView)findViewById(R.id.backward);
        if(currentPosition==0)
        {
            fastback.setEnabled(false);
            fastfor.setEnabled(true);
            forward.setEnabled(true);
            backward.setEnabled(false);
        }
        else if(currentPosition==recipes.size()-1)
        {
            Log.d("position","close");
            fastback.setEnabled(true);
            fastfor.setEnabled(false);
            forward.setEnabled(false);
            backward.setEnabled(true);
        }
    }

    public void display(final ArrayList<Recipies> recipes)
    {
        final ImageView fastfor=(ImageView)findViewById(R.id.fast_forward);
        final ImageView fastback=(ImageView)findViewById(R.id.fast_backward);
        final ImageView forward=(ImageView)findViewById(R.id.forward);
        final ImageView backward=(ImageView)findViewById(R.id.backward);
        Button finish=(Button)findViewById(R.id.finish);
        currentPosition=0;
        setData(recipes);

//        fastback.setEnabled(false);
//        fatfor.setEnabled(false);
//        forward.setEnabled(false);
//        backward.setEnabled(false);

        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        fastback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                currentPosition=0;
                position(recipes);
                Log.d("position", ((String.valueOf(currentPosition))));
                setData(recipes);

            }
        });
        fastfor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                currentPosition=recipes.size()-1;
                position(recipes);
                Log.d("position", ((String.valueOf(currentPosition))));
                setData(recipes);
            }
        });
        backward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                currentPosition-=1;
                position(recipes);
                Log.d("position", ((String.valueOf(currentPosition))));
                setData(recipes);
            }
        });
        forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.d("position", ((String.valueOf(currentPosition))));
                currentPosition+=1;
                position(recipes);
                Log.d("position", ((String.valueOf(currentPosition))));
                setData(recipes);
            }
        });



    }
}

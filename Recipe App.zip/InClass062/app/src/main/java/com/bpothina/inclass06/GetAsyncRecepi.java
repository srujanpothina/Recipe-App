package com.bpothina.inclass06;

import android.os.AsyncTask;
import android.util.Log;
import android.view.View;

import org.xmlpull.v1.XmlPullParserException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by BhaBhaHP on 10/2/2017.
 */

public class GetAsyncRecepi extends AsyncTask<String, String, ArrayList<Recipies>>
    {
    ArrayList<Recipies> r=new ArrayList<Recipies>();
        MainActivity activity;

        public GetAsyncRecepi(MainActivity mainActivity) {
            this.activity=mainActivity;
        }



//        public GetRecipies() {
//        }



        @Override
        protected ArrayList<Recipies> doInBackground (String...params){
        try {
            URL url = new URL(params[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            int statusCode = con.getResponseCode();


            if (statusCode == HttpURLConnection.HTTP_OK) {
                InputStream inputStream = con.getInputStream();
                Log.d("demo", String.valueOf(inputStream));
                r=RecipieParser.parseContent(inputStream);
                Log.d("demo321", String.valueOf(r.size()));
                return r;
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (ProtocolException pe) {
            pe.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (XmlPullParserException xmlPullEx) {
            xmlPullEx.printStackTrace();
        }
        return null;
    }


        @Override
        protected void onPostExecute (ArrayList<Recipies> recepi) {
            activity.setDataValue(r);
           // super.onPostExecute(r);

            Log.d("demo123", String.valueOf(recepi.size()));

        }
}
